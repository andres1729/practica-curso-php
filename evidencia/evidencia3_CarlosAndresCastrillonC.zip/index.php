﻿
<!-- Carlos Andres Castrillon Castro 
     programa de formacion: Desarrollador web PHP
     En la lineas del codigo usadas en biblioteca.php se usa la setencia swith dentro de las funciones. En el archivo biblioteca.php a modo de comentario se especifica porque decido usar la setencia swith
 -->    


<!DOCTYPE html>
<html>
   



    <head>
        <title>Evidencia de aprendizaje: Uso de las funciones</title>
        <meta http-equiv="Content-Type" 
              content="text/html; charset=ISO-8859-1" />
    </head>
    <body>
        <?php
        /* En este archi se uas las bibliotecas de
         * funciones creadas. Como se aprendio en el material de aprendizaje, solo hace falta recopilar
         * las funciones en un archivo .php y luego incluirlo o requerirlo
         * dentro del archivo donde se van a requerir las funciones
         */
      
        
        require_once './biblioteca.php';
        
       
      
        ?>
    </body>
</html>
